Thanks for Trialling C# CVS Data Reader
-------------------------------------------------------
Can read and write both csv, other delimited files, and fixed width files.

Instructions
------------
Copy xline.IO.dll to your project and reference it.
The recommended installation it to copy it to a folder called something like 'libs' or 'BuildReferences', then reference it from your Visual Studio Solution and use the default setting of 'Copy to Local' = true. This will result in the the files being copied to your bin folder.

The dll is compiled in .NET 4.0 so it is supported in .NET 4.0 or greater for complete flexibility. If you need to support an earlier version of the .NET framework please send me a message and we will see what we can do.

IMPORTANT: Copy xline.IO.lic to your solutions bin\Debug and bin\Release folders. The license file is required for proper execution.